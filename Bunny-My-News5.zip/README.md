# Bunny My News 

This Chrome extension that replaces images of Donald Trump with random bunnies is forked and edited from Tom Royal's Make America Kittens Again tomroyal.com.

https://chrome.google.com/webstore/detail/bunny-my-news/hejjhgihcmepiacbeomcjgmgopkhmaak


Katie Jergens
github.com/kjergens/Bunny-My-News
